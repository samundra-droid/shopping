package com.example.Shopping_model;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingModelApplicationTests {

	@Test
	void contextLoads() {
	}

}
